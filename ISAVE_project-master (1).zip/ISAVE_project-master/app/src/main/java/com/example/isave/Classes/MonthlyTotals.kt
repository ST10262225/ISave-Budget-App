package com.example.isave.Classes

data class MonthlyTotals(val id:Int, val category:String, val amount:Double)
