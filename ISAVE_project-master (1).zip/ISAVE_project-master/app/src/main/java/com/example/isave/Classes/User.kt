package com.example.isave.Classes

data class User(val id:Int, val username:String, val password:String)
