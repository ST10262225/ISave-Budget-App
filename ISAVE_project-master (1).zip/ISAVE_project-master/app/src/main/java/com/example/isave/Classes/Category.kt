package com.example.isave.Classes

data class Category(val id:Int,val description:String)
