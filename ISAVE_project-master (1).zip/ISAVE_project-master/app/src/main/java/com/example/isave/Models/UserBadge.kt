package com.example.isave.Models

data class UserBadge(
    val id: Int = 0,
    val badgeId: String,
    val earnedDate: Long
)
