Application used to create this app is android studio meerkat 2024 version.
The database that is used is SQLite.

This is the link to the video showing how to use the app:  https://youtu.be/_o9GiB5gsxs?si=ctkwIim5WTnZgjP6 


How to run the app on android studio and/or on your android phone:
1. Firstly after opening the project using android studio, go to the green arrow at the top ribbon of the studio then run it.
2. If it happens it problems running it on android studio, you can always run it on your android device.
3. In order to do so you go to the top left and press the main menu icon then click on build.
4. After selecting it go to generate application apk then it will load then at the bottom right a pop up will appear then click "locate".
5. Then "app-debug" will be downloaded. After it has completed send the file to your whatsapp then install it.
6. When it is done you will click on it, it has a robot logo and you can successfully run the application.

APP ICON ON THE MOBILE PHONE (took full screenshot to actually show that its from a mobile phone):
1. It is the one highlighted and indicated with a green highlighter called ISAVE.
![image](https://github.com/user-attachments/assets/e6b61487-8ebc-47f3-802a-73b2a8da85f6)

How to use our iSave budgeting app:
1. The launcher page will be the login page. It has the option of registering if you did not before.
2. Press on the link " Register" then it will take you to the sign up page where you will be allowed to enter your username, password and confirm your password.
3. It will go back to the login page once registered successfully, then you proceed to log in using your registered credentials. 

![image](https://github.com/user-attachments/assets/7bac3095-622f-4376-abd9-bc9a24ba70c9)


4. After putting correct credencials it will take you to the home page.
5. Our home page has a navigation bar at the bottom that consists of 5 icons.
![image](https://github.com/user-attachments/assets/a3f7de76-c000-41e0-bc7e-1394e20c7704)


6. For adding the category you select the forth icon from your left then press on "Expense categories" then add the bottom right you will see a plus sign, click it and it shall lead you to the add new category page.
7. Click on "Title" then enter your category, after doing so you press the save button.
8. You you click the green plus icon on the navigation bar it will take you to the add transaction page.
9. On that page you can add a description of the category and add the category itself, add date, and add amount.
10. On the top right theres an option of taking a picture of your item then upload it.
![image](https://github.com/user-attachments/assets/bc7c07a5-51d8-4158-aaa2-f82c63688d9b)


11. You then press create, to see the displayed transactions with full details you press the second button from the left then you will see the transaction you added.
12. The last icon on the far right end is for displaying the totals of the money spent on categories.
![image](https://github.com/user-attachments/assets/371d1ca4-749e-4d0c-96f9-61dfa4d2d9db)

13. When you click on the second icon from your left, you will go to transaction page where you will see the graph/ pie chart showing the amount spent per category over a selectable period.
![image](https://github.com/user-attachments/assets/992d6d3a-95ee-4dc0-bba6-e2fd666fbbc4)

15. The visual format of how the user is doing with staying between their min and max spending goals is accessable in the category totals page. There are 3 buttons underneath the totals, Set spending goals,view badges and view spending progress.
16. First button is for setting the min and max of your spending goal then the second one is for viewing it in a visual format.
17. The third button is for viewing your badges you recieved after staying within budget.
![image](https://github.com/user-attachments/assets/785599e9-0458-460f-9471-62170fed1781)
![image](https://github.com/user-attachments/assets/f546235c-3334-4d55-88b0-931e6236d14f)
![image](https://github.com/user-attachments/assets/2312c6b5-0bd3-40dd-918a-09999e5ce56d)
![image](https://github.com/user-attachments/assets/2dffd2c6-e7c9-464e-a521-f779324c69e6)

OUR OWN TWO FEATURES WE IMPLEMENTED:

1. Dark mode
you change it buy pressing 3 dotted line at the top green bar at the homepage. The text : Toggle dark mode will appear then you tick the block.

![image](https://github.com/user-attachments/assets/ee0183e7-31fa-4d5a-958e-4304baf154d6)

THIS IS HOW IT BECOMES AFTER BEING ON DARK MODE: 

![image](https://github.com/user-attachments/assets/f9a202bd-0707-40a9-8a7f-b7dbf9abaded)

3. Deletion of transactions
you can delete the transactions by press and hold the transaction you want to delete then a pop-up will show asking are you sure, then if sure you click delete. it shall be deleted even on the graph.

![image](https://github.com/user-attachments/assets/662ede29-8e96-4f76-920b-6a3aafa55556)


PURPOSE OF THIS APPLICATION (ISAVE Budgeting App)

The crutial role played by our application is to keep track of your earnings. It is budgeting app where you can easily cateorize your spendings over a certain period of time. Its a very user friendly platform, the great features that it consists are listed above.




